#include <stdio.h>
#include <Windows.h> // Required to Read and Write to Registry
#include <winreg.h>

int changemac();  //This Changes the Registry key for MAC address from user input 
int savenicmac(); //this function saves the current MAC address in registry to a txt file


//---------------------------------------------------------------------------------------------------------------

int main()           //Main is for user I/O
{
	printf("\nWelcome to Max's MAC spoofing tool for Windows\nUse at your own risk!");  //Welcome message

	char cont[1]; //Tetminator for the do while function

	do {
		int choice; //variable for choosing function 
		printf("\n\nTO CHANGE YOUR MAC ADDRESS ENTER: 1 | TO SAVE YOUR CURRENT MAC ADDRESS ENTER: 2 "); //prompt user to choose 
		scanf_s("%d", &choice);

		if (choice == 1)   //Runs changemac function 
			changemac();

		if (choice == 2)   //Runs savenicmac function 
			savenicmac();

		printf("\nDo you want to exit? y/n");
		scanf_s("%c", &cont);

	} while (cont != "y");

	return 0;

}

//-----------------------------------------------------------------------------------------------------------------

int changemac()  //Function Definition for the function to change MAC in Registry
{
	savenicmac(); //Possibly Redundant but important before user makes a change

	char newmac[17];
	printf("\nPlease enter a VALID MAC address | EX: 00:1B:44:11:3A:B7 |");
	scanf("c, &newmac);

	//RegOpenKey()   ! These Functions are commented because I could not get them to work before Due Date !
	//RegSetValueA()      ^
	//SaveKeyValue()      ^
	//CloseKeyValue()     ^

	return 0;
}

int savenicmac()   //Function Definition to save the current MAC into a designated .txt
{
	//      RegOpenKey()


	char savemac[17];  // = RegValueA()



	FILE *file = fopen_s("mymacs.txt", "a");
	fputs("\n", file);
	fputs(savemac, file);
	fclose(file);
	printf("\nChanges were succsessfully made to ~/mymacs.txt");


	//RegCloseKey()
	return 0;
}

