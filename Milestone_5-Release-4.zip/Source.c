//Max Ashbridge 
//Milestone 5 - Release 4
//   04/17/21

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <Windows.h> // Required for pre-defined windows functions
#include <winreg.h>  // Required to work with Windows 10 Registry
#include <string.h>

int createmac();  //This Changes the Registry key for MAC address from user input 
int savenicmac(); //this function saves the current MAC address in registry to a txt file
int dowhile(); //Includes main functionality and keeps main running
void authentication(); //password protection for the program

//---------------------------------------------------------------------------------------------------------------
//                                               MAIN FUNCTION                                                  |
//---------------------------------------------------------------------------------------------------------------

int main()
{
	printf("------------------------------------------------------------------------------------");
	printf("\nWelcome to Max's MAC spoofing tool for Windows\n\n WARNING: Use at your own risk!");  //Welcome message
	printf("\n-----------------------------------------------------------------------------------");

	authentication();
	choosefunctionality();

	printf("\n Good Bye!");



	return 0;
}
//----------------------------------------------------------------------------------------------------------------
//                                            FUNCTION DEFINITIONS                                               |
//----------------------------------------------------------------------------------------------------------------


int createmac()  //Function Definition for the function to change MAC in Registry
{

	//--------------------------------------------------------------
	//                 Typical MACs Table                          |
	//--------------------------------------------------------------
	struct MACS {

		char manufacturer[10];
		char model[10];
		char address[18];
		union {          //Union Is Used Becuase not all devices have specific model years for MAC schema
			struct {
				int modelyear;
			};
		}year;

	};

	//APPLE definition 
	struct MACS apple;
	strcpy(apple.model, "MAC Book");
	strcpy(apple.address, "2C-88-F2-CE-E8-E9");
	strcpy(apple.manufacturer, "Apple");
	apple.year.modelyear = 2019;



	//RAZER definition
	struct MACS razer;
	strcpy(razer.model, "Blade 15");
	strcpy(razer.address, "D3-86-F6-8D-1B-2A");
	strcpy(razer.manufacturer, "Razer");

	//--------------------------------------------------------------
	//                Registry Editor                              |
	//--------------------------------------------------------------

	char newmac[18];

	printf("\nYou Have Chosen To Enter a New MAC Address");
	printf("\nIf you want to see Manufacturer examples enter 1: ");
	int  decision;
	scanf("%d", &decision);


	if (decision == 1)
	{

		printf("\n %s", apple.manufacturer);
		printf(" %s ", apple.model);
		printf(" %s", apple.address);
		printf(" %d", apple.year.modelyear);
		printf("\n %s", razer.manufacturer);
		printf(" %s ", razer.model);
		printf(" %s", razer.address);

	}

	printf("\n\nPlease enter a VALID MAC address | EX: %s ", apple.address);
	printf(" : ");
	scanf("%s", &newmac);
	LONG lReg;
	HKEY hKey;

	//CREATES NEW KEY TO AVOID OVERRIDING NESSECARY REGISTRY KEYS (INTENDED FOR TESTING
	lReg = RegCreateKeyEx(
		HKEY_LOCAL_MACHINE,
		L"Software\\Test\\Product\\MACTEST",  //Folder to insert new key 
		0,                                   // Not important
		NULL,                               // Not Important 
		REG_OPTION_NON_VOLATILE,           // Not Important
		KEY_ALL_ACCESS | KEY_WOW64_64KEY, // Define 64 bit operating system 
		NULL,                            // Not Important
		&hKey,                          // Key value
		NULL);                         // Not important

	//EDITS KEY THAT WAS CREATED ABOVE
	RegSetValueEx(
		hKey,                        // key to write to 
		L"MAC",                     // Key name 
		NULL,                      // Not Important
		REG_SZ,                   // Key data type: string
		(LPBYTE)newmac,          // value 
		18          // Byte Size of value
	);

	RegCloseKey(hKey);  //Key needs to be closed for successful write

	printf("\nSuccess! Your new MAC address has been written");

	return 0;
}

//----------------------------------------------------------------
//                         SAVE MAC FUNCTION                     |
//----------------------------------------------------------------

int savenicmac()   //Function Definition to save the current MAC into a designated .txt
{
	char savemac[20]; //temporarily user defined until registry is updated

	printf("\n\nPlease enter MAC: ");   //user defined mac
	scanf("%s", &savemac);


	FILE* file;

	file = fopen("mymacs.txt", "r+");  //opens file
	fprintf(file, "%s %s", " | ", savemac);
	fclose(file);
	printf("\nChanges were succsessfully made to ~/mymacs.txt");

	return 0;

}






//--------------------------------------------------------------
//                 AUTHENTICATION FUNCTION                     |
//--------------------------------------------------------------

void authentication()
{

	static char pword[8] = "password";
	char authenticate[20];
	printf("\nEnter Password:");
	scanf("%s", &authenticate);

	if (strcmp(pword, authenticate) == 0)
	{
		printf("\nAuthentication Successful");

	}
	else
	{
		authentication();
	}




}



int choosefunctionality()
{
	int cont = 1;

	while (cont == 1 )
	{
		int decision;
		printf("\n Enter 1 to Change your Mac | Enter 2 to save your MAC: ");
		scanf("%d", &decision);

		if (decision == 1)
		{
			createmac();
		}
		if (decision == 2)
		{
			savenicmac();
		}

		printf("\nWould you Like to continue (1 for yes): ");
		scanf("%d", &cont);

	}
	return 0;
}