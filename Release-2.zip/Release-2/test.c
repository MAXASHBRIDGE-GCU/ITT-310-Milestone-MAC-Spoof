//Max Ashbridge 
//Milestone 3 - Release 2
//03/17/21

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h> // Required for pre-defined windows functions
#include <winreg.h>  // Required to work with Windows 10 Registry
#include "macro.h";

int changemac();  //This Changes the Registry key for MAC address from user input 
int savenicmac(); //this function saves the current MAC address in registry to a txt file

//---------------------------------------------------------------------------------------------------------------

int main()           //Main is for user I/O
{
	printf("\nWelcome to Max's MAC spoofing tool for Windows\nUse at your own risk!");  //Welcome message

	char cont; //Tetminator for the do while function

	do {
		int choice; //variable for choosing function 
		printf("\n\nTO CHANGE YOUR MAC ADDRESS ENTER: 1 | TO SAVE YOUR CURRENT MAC ADDRESS ENTER: 2 "); //prompt user to choose 
		scanf("%d", &choice);

		if (choice == 1)   //Runs changemac function 
			changemac();

		if (choice == 2)   //Runs savenicmac function 
			savenicmac();

		printf("\nDo you want to exit? y/n");
		scanf("%c", &cont);

	} while (cont != "y");

	return 0;

}

//-----------------------------------------------------------------------------------------------------------------

int changemac()  //Function Definition for the function to change MAC in Registry
{
	savenicmac(); //Possibly Redundant but important before user makes a change

	char newmac[17];  //user input variable for the new MAC


	printf("\nPlease enter a VALID MAC address | EX: 00:1B:44:11:3A:B7 |");
	scanf_s(17, "%c", &newmac);

		//RegOpenKey()   ! These Functions are commented because I could not get them to work before Due Date !
		//RegSetValueA()      ^
		//SaveKeyValue()      ^
		//CloseKeyValue()     ^

		return 0;
}

int savenicmac()   //Function Definition to save the current MAC into a designated .txt
{
	//      RegOpenKey()
	
	char savemac[17]; //temporarily user defined until registry is updated
	
	printf("\n\nPlease enter MAC: ");
	scanf( "%s", savemac);
	
     

	FILE* file = fopen("mymacs.txt", "r+");
	fputs("\n", file);
	fputs(savemac, file);
	fclose(file);
	printf("\nChanges were succsessfully made to ~/mymacs.txt");



	//RegCloseKey()
	return 0;
}
